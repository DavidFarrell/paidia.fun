---
title: "Play Online"
weight: 3
header_menu: true
---

![Play on Tabletopia](images/tabletopia.png)

##### Play on Tabletopia

You can [play our game on Tabletopia](https://tabletopia.com/players/demo3449871/5znbmp). It's completely free. It should work on most computers in most web browsers. We find it works best in Chrome. It's hard to play with a trackpad so try to find a mouse if you can.
