---
title: "The Game"
weight: 1
---

We have made this game.  This is a fun game.  We'd like for you to play this game.

>this game rocks. --- most players probably

---
*David Note - I'll delete the below but it's to remind me*

`Hugo-Scroll` theme alternates colors of sections that are placed on single page. 
The landing screen is meant to be visually striking.

Single-page approach is oriented towards small to medium content length, that won't overwhelm the user. 
You can also delegate lengthier, less important or more sizeable content to [dedicated pages](services).

By the way this welcome section won't show in the cover menu.