---
title: "Contact"
weight: 6
header_menu: true
---

{{<icon class="fa fa-envelope">}}&nbsp;[david@paidiaconsulting.com](mailto:david@paidiaconsulting.com)

{{<icon class="fa fa-phone">}}&nbsp;[+44 7595 393964](tel:+447595393964)

Let us get in touch if you'd like to know more, help us distribute this game, or hire us to make a game for you!
